<?php 
	include_once'database/shared/openDbConnection.php';
	//Beveiliging
	if(!isset($_SESSION['login'])){
		header('location: login.php');
	}

	if(isset($_GET['id'])){
		$statement=$conn->prepare('DELETE FROM berichten WHERE id=:id;');
		$statement->execute([
				'id'=>$_GET['id']
			]);
	}

	header('location: berichten.php');
?>