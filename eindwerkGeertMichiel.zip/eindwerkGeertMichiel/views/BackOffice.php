<!--variables-->
<?php

?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="utf-8" />
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Geert Put, Michiel Peters">
    <title>Backoffice Eindwerk</title>
    <!--styles-->
    <link href="../css/backoffice.css" rel="stylesheet" />
    <!--scripts-->

</head>
<body>
<div id="siteContainer">
 <h1>Backoffice</h1>
    <!--site content-->
    <div id="contentContainer">
        <article>
            <h2>aankomende evenementen</h2>
            <div id="evenementenContainer">
                <?php
                //get events from database
                include_once "database/getEventsFromDb.php";
                //insert events in html page
                foreach($events as $event){
                echo "<div><article>";
                        echo "<h3>" .$event['title'] ."</h3>";
                        echo "<p>" .$event['description'] ."</p>";
                        echo "<time>" .$event['start'] ."</time><br/>";
                        echo "<a href='database/deleteEventFromDb.php?id=". $event['id'] ."' >Verwijder</a>";
                        echo "</article></div>";
                };?>

            </div>
        </article>
    </div>
</div>
</body>
</html>
