﻿<!--variables-->
<?php
$pageTitle = "Home";
$activeNav = 1;
?>
<!--site header-->
<?php include_once "shared/header.php" ?>
<!--site content-->
<div id="contentContainer">
    <article>
       <h2>Brasserie "Name to be decided"</h2>
        <p>Welkom bij het gezelligste plekje in belgie.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium adipisci at aut commodi consectetur culpa cumque earum, est eveniet ex excepturi fuga id illo impedit laudantium modi mollitia nam nisi, perferendis, perspiciatis quo repudiandae sapiente suscipit ut veniam vero? Accusantium, necessitatibus nulla! Dolorem ex mollitia optio repudiandae tempora tenetur!</p>
    </article>
    <article>
        <h2>Evenementen</h2>
        <p>
            Volgende evenementen staan binnenkort op het programma.
        </p>
        <div id="evenementenContainer">
            <div>
                <article>
                    <h3>Karaoke avond</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, alias animi at consequatur cum dolor impedit laboriosam nihil perferendis perspiciatis possimus provident quidem quisquam quod sint totam velit. Autem delectus dolores fuga fugiat ipsum modi quidem voluptatibus. Ab, culpa enim exercitationem fuga incidunt iste necessitatibus nihil odio placeat sequi soluta.</p>
                    <time>15 Maart | 19:00</time>
                </article>
            </div>
            <div>
                <article>
                    <h3>Karaoke avond</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, alias animi at consequatur cum dolor impedit laboriosam nihil perferendis perspiciatis possimus provident quidem quisquam quod sint totam velit. Autem delectus dolores fuga fugiat ipsum modi quidem voluptatibus. Ab, culpa enim exercitationem fuga incidunt iste necessitatibus nihil odio placeat sequi soluta.</p>
                    <time>15 Maart | 19:00</time>
                </article>
            </div>
            <div>
                <article>
                    <h3>Karaoke avond</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, alias animi at consequatur cum dolor impedit laboriosam nihil perferendis perspiciatis possimus provident quidem quisquam quod sint totam velit. Autem delectus dolores fuga fugiat ipsum modi quidem voluptatibus. Ab, culpa enim exercitationem fuga incidunt iste necessitatibus nihil odio placeat sequi soluta.</p>
                    <time>15 Maart | 19:00</time>
                </article>
            </div>
            <div>
                <article>
                    <h3>Karaoke avond</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium, alias animi at consequatur cum dolor impedit laboriosam nihil perferendis perspiciatis possimus provident quidem quisquam quod sint totam velit. Autem delectus dolores fuga fugiat ipsum modi quidem voluptatibus. Ab, culpa enim exercitationem fuga incidunt iste necessitatibus nihil odio placeat sequi soluta.</p>
                    <time>15 Maart | 19:00</time>
                </article>
            </div>
        </div>
    </article>
    <article>
        <h2>Over ons</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium adipisci at aut commodi consectetur culpa cumque earum, est eveniet ex excepturi fuga id illo impedit laudantium modi mollitia nam nisi, perferendis, perspiciatis quo repudiandae sapiente suscipit ut veniam vero? Accusantium, necessitatibus nulla! Dolorem ex mollitia optio repudiandae tempora tenetur!</p>
    </article>
</div>
<!--site footer-->
<?php include_once "shared/footer.php" ?>


