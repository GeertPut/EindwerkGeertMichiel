<?php 
	include_once'database/shared/openDbConnection.php';

	//Beveiliging
	if(!isset($_SESSION['login'])){
		header('location: login.php');
	}

	$statement=$conn->query('SELECT * FROM berichten;');
	$berichten=$statement->fetchAll();

	$pageTitle='Berichten';
	$activeNav=0;
	include_once'shared/header.php';
?>
	<?php if(count($berichten)){ ?>
	<ul>
		<?php foreach ($berichten as $bericht) {?>
		<li>
			<?php print $bericht['naam']; ?><br>
			<?php print $bericht['email']; ?><br>
			<?php print $bericht['onderwerp'];?><br>
			<?php print $bericht['bericht'];?><br>
			<p><a href="bericht-verwijderen.php?id=<?php print $bericht['id'];?>">Verwijderen</a></p>
			<hr>
		</li>
		<?php } ?>
	</ul>
	<?php } else { ?>
	<p>Er zijn geen berichten ingezonden.</p>
	<?php } ?>
<?php 
	include_once'shared/footer.php';
?>