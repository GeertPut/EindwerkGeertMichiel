<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="utf-8" />
    <meta name="description" content="Dit is het eindwerk van Geert Put en Michiel Peters voor HTML, CSS, PHP en Photoshop">
    <meta name="keywords" content="HTML, CSS, PHP, Photoshop, Eindwerk">
    <meta name="author" content="Geert Put, Michiel Peters">
    <title>Eindwerk Geert Michiel</title>
    <!--styles-->
    <link href="../css/style.css" rel="stylesheet" />
    <!--scripts-->
	
</head>
<body>
    <div id="siteContainer">
        <!--site header-->
        <header>
            <a href="home.php"><img src="../images/placeholder_350x150.png" alt="logo" /></a>
            <div>
                <nav>
                    <ul>
                        <li><a href="home.php" <?php if( $activeNav == 1){print "class='activeNav'";} ?> >Home</a></li>
                        <li><a href="menu.php" <?php if( $activeNav == 2){print "class='activeNav'";} ?> >Menu</a></li>
                        <li><a href="fotos.php" <?php if( $activeNav == 3){print "class='activeNav'";} ?> >Photo's</a></li>
                        <li><a href="contact.php" <?php if( $activeNav == 4){print "class='activeNav'";} ?> >Contact</a></li>
                    </ul>
                </nav>
                <h1><?php print $pageTitle ?></h1>
            </div>

        </header>