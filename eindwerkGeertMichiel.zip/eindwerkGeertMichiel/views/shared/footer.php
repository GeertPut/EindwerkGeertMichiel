        <footer>
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Twitter</a></li>
            </ul>
            <a href="#">Copyright</a>
        </footer>       
    </div>
</body>
</html>