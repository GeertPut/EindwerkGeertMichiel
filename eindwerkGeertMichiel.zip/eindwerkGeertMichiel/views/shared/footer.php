        <footer>
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Twitter</a></li>
            </ul>
            <ul>
                <li><a href="BackOffice.php">Backoffice</a></li>
                <li><a href="#">Copyright</a></li>
            </ul>
        </footer>       
    </div>
</body>
</html>