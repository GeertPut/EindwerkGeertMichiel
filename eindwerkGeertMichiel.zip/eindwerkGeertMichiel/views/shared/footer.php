        <footer>
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Twitter</a></li>
            </ul>
            <ul>
                <li><a href="BackOffice.php">Backoffice</a></li>
                <li><a href="#">Copyright</a></li>
                <?php if(!isset($_SESSION['login'])){ ?>
                <li><a href="login.php">Login</a></li>
                <?php } ?>
                <?php if(isset($_SESSION['login'])){ ?>
                <li><a href="logout.php">Logout</a></li>
                <?php } ?>
                <?php if(isset($_SESSION['login'])){ ?>
                <li><a href="berichten.php">Berichten</a></li>
                <?php } ?>
            </ul>
        </footer>       
    </div>
</body>
</html>