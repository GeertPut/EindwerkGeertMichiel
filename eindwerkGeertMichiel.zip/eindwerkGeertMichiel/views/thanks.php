<!--variables-->
<?php
$activeNav=4;
$pageTitle = "Thanks";
?>
<!--site header-->
<?php include_once "shared/header.php" ?>
<!--site content-->
<div id="contentContainerThanks">
	<p>Bedankt voor het verzenden van uw bericht.</p>
</div>
<!--site footer-->
<?php include_once "shared/footer.php" ?>

